#!/usr/bin/env bash
# Initializes the three corpus repositories, creates the baseline tag and the
# SCA-02 scenario branch, and pushes everything to the supplied remotes.
#
# Usage:
#   ./push.sh <node-remote-url> <python-remote-url> <java-remote-url>
#
# Example:
#   ./push.sh git@github.com:ORG/poc-node-sca.git \
#             git@github.com:ORG/poc-python-sca.git \
#             git@github.com:ORG/poc-java-sca.git
set -euo pipefail

if [ "$#" -ne 3 ]; then
  echo "usage: $0 <node-remote-url> <python-remote-url> <java-remote-url>" >&2
  exit 1
fi

if ! git config user.email > /dev/null; then
  echo "git identity is not configured; set user.name and user.email first" >&2
  exit 1
fi

ROOT="$(cd "$(dirname "$0")" && pwd)"
REPOS=(poc-node-sca poc-python-sca poc-java-sca)
REMOTES=("$1" "$2" "$3")
MSGS=("Introduce vm2 3.9.19" "Introduce pillow 8.1.0" "Introduce commons-collections 3.2.1")

for i in 0 1 2; do
  repo="${REPOS[$i]}"
  remote="${REMOTES[$i]}"
  dir="$ROOT/$repo"

  if [ -d "$dir/.git" ]; then
    echo "$repo: .git already exists, skipping init (remove it to rebuild)" >&2
    exit 1
  fi

  echo "== $repo =="
  git -C "$dir" init -q -b main
  git -C "$dir" add -A
  git -C "$dir" commit -qm "Baseline dependency set"
  git -C "$dir" tag sca-baseline-v1

  git -C "$dir" checkout -qb scenario/sca-02-critical-introduction
  git -C "$dir" apply "$ROOT/patches/$repo-sca02.patch"
  git -C "$dir" add -A
  git -C "$dir" commit -qm "${MSGS[$i]}"
  git -C "$dir" checkout -q main

  git -C "$dir" remote add origin "$remote"
  git -C "$dir" push -q -u origin main
  git -C "$dir" push -q origin sca-baseline-v1
  git -C "$dir" push -q origin scenario/sca-02-critical-introduction
  echo "$repo: pushed main, sca-baseline-v1, scenario branch"
done
