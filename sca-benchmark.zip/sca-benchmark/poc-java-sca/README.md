# poc-java-sca

Maven application. Part of a dependency analysis corpus; the dependency set
is intentional and must not be upgraded.

Build:

    mvn -q package

The workflow at .github/workflows/dependency-submission.yml submits the
resolved dependency graph on push to main; it must complete before the
repository dependency graph includes Maven transitives.

Branches: main carries the baseline tagged sca-baseline-v1. The branch
scenario/sca-02-critical-introduction adds one dependency and exists for
pull request review checks.
