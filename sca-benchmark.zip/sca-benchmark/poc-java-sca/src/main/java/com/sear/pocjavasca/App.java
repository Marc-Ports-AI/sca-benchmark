package com.sear.pocjavasca;

import java.util.HashMap;
import java.util.Map;

// Tier 1: imported and advisory-relevant API called.
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.commons.text.StringSubstitutor;

// Tier 2: imported, advisory-relevant configuration never enabled.
// Jackson arrives transitively through spring-boot-starter-web; default
// typing is never activated anywhere in this codebase.
import com.fasterxml.jackson.databind.ObjectMapper;

// Tier 3: commons-fileupload is declared in pom.xml and never imported.
// SnakeYAML arrives transitively and is never imported.

public final class App {

    private static final Logger LOG = LogManager.getLogger(App.class);

    private App() {
    }

    public static void main(String[] args) throws Exception {
        LOG.info("poc-java-sca starting");

        Map<String, String> values = new HashMap<>();
        values.put("service", "poc-java-sca");
        StringSubstitutor sub = new StringSubstitutor(values);
        LOG.info(sub.replace("running ${service}"));

        ObjectMapper mapper = new ObjectMapper();
        HealthStatus status = mapper.readValue(
                "{\"status\":\"ok\"}", HealthStatus.class);
        LOG.info("health: {}", status.getStatus());
    }

    public static final class HealthStatus {
        private String status;

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }
    }
}
