# Ground truth register

All files derive from the reviewed GitHub Advisory Database at commit
524f896ffaae2a2b42c61096d6c94d8e3984edcd (2026-07-06T22:55:38+00:00),
recorded in advisory_db_snapshot.json. The reviewed set is the data source
behind Dependabot alerts, so recall measured against these files is direct
for GitHub tooling; other vendors map through the CVE and GHSA identifiers
carried on every row.

## Files

component_register.csv: one row per planted component. Columns: probe_id,
repo, ecosystem, package, version, relation (direct or transitive), chain
(logical dependency path), reachability (called, imported-only,
declared-only, or n/a for transitives), probe_class, tags, live_advisories,
withdrawn_advisories, max_severity, fix_clears_all (lowest version clearing
every live advisory), notes.

expected_findings.csv: one row per (component, advisory) pair. Rows with
severity WITHDRAWN are exclusions, not expectations. 146 live rows,
3 exclusions.

scenario_sca02_expected.csv: advisories attached to the packages introduced
on the scenario branch, verified against the same snapshot.

inventory_npm.csv: every install path in the committed package-lock.json
(101 paths, 100 unique package and version pairs). This is the denominator
for npm SBOM completeness. The Python denominator is the 17 pins in
requirements.txt. The Maven denominator is the seven direct entries in
pom.xml plus the transitive set confirmed by tools/verify_maven_tree.sh.

advisory_attribution.json: raw attribution output for every corpus tuple.
pypi_verification.json: existence and license metadata for every Python pin.

## Probe classes

tp-direct and tp-transitive rows carry at least one live advisory and are
the recall numerator sources. expected-clean rows are verified to have zero
live advisories at the snapshot; any finding a tool reports on them is a
false positive candidate for adjudication. The manifest-floor row
(node-fetch) has a vulnerable manifest range floor and a clean locked
version; the correct result is no finding. The organic-volume row
(tomcat-embed-core, 37 live advisories) is scored on grouping and canonical
counting, not per-advisory enumeration.

## Tags

stale-lock: manifest range admits patched releases while the lockfile pins
a vulnerable version; lockfile evaluation is required for a correct result.
dedup-multipath: same tuple installed at more than one path.
dedup-multiversion: same package present at two versions in one tree.
reachability-tier: rows where source usage differs from declaration; tools
claiming reachability analysis are compared on their disposition here.
pending-resolve: Maven transitive expected from the Spring Boot 2.6.6 BOM;
confirm with tools/verify_maven_tree.sh before final scoring.
disputed: the matching set includes CVE-2016-1000027, which the vendor of
the affected package disputes as usage dependent. Record each tool's
disposition; a suppression with rationale and a reported finding are both
acceptable outcomes, silence is not.
reclassified: chosen as a post-fix version of an older advisory, later
matched by an advisory published after selection. The register follows the
snapshot, not the selection intent.
withdrawn-present: a withdrawn advisory also matches this version.
carrier: exists to pull a transitive under test; itself verified clean or
scored separately.
volume: high advisory count; exercises grouping in vendor output.
license-agpl, license-lgpl, license-gpl-exception, license-dual,
license-unknown: license policy rows; chardet arrives transitively, itext
and pymupdf are the AGPL entries, mysql-connector-j carries the FOSS
exception, jsonify and itsdangerous have nonstandard license metadata.

## Scoring linkage

Detection and Accuracy uses these files directly: recall is detected live
expected findings over the per-ecosystem totals (35 npm,
40 PyPI, 71 Maven), reported separately for
direct and transitive relations. Precision counts adjudicated false
positives from the expected-clean and manifest-floor rows plus any finding
outside the register that review rejects. Remediation quality is scored on
fix_clears_all: log4j-core guidance must reach 2.17.1 or later, not stop at
2.15.0. Reporting and Visibility uses the volume rows. The license rows
feed the policy enforcement checks.
