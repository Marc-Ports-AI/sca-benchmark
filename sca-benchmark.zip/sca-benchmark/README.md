# SCA benchmark corpus

Three repositories with pinned dependency sets, a register of every planted
component, and the advisories expected from a scan of each baseline. All
advisory data is attributed against a pinned snapshot of the reviewed GitHub
Advisory Database (commit 524f896ffaae2a2b42c61096d6c94d8e3984edcd,
2026-07-06T22:55:38+00:00).

## Layout

    poc-node-sca/       npm corpus: package.json plus committed package-lock.json
    poc-python-sca/     PyPI corpus: pyproject.toml plus pinned requirements.txt
    poc-java-sca/       Maven corpus: pom.xml plus dependency submission workflow
    ground-truth/       register, expected findings, inventories, snapshot pin
    patches/            scenario branch content, one patch per repository
    tools/              attribution and verification scripts
    push.sh             repository initialization and push

Only the three repository directories are pushed to the evaluation org.
Keep ground-truth, patches, and tools in a private location; they are the
adjudication material, not scan input.

## Baseline and scenario

push.sh creates one commit per repository tagged sca-baseline-v1, then a
branch named scenario/sca-02-critical-introduction that adds one package
with known advisories per ecosystem (vm2 3.9.19, pillow 8.1.0,
commons-collections 3.2.1). Opening a pull request from that branch into
main is the SCA-02 gate test. Expected results for the branch are in
ground-truth/scenario_sca02_expected.csv (62 live advisories:
31 npm, 29 PyPI, 2 Maven).

## Counting rules

A finding is the tuple (repository, package, version, advisory). Duplicate
install paths of the same tuple count once; the npm tree contains qs 6.7.0
at two paths for this reason. Advisories withdrawn at the snapshot are
excluded from scoring in both directions: reporting one is not an error,
missing one is not a miss. All dependencies are runtime scope; there are no
dev-only entries. Each repository is scored on its own; results are not
pooled across ecosystems until the category rollup.

## Baseline expectations

146 live expected findings across 48 register rows:
35 npm, 40 PyPI, 71 Maven, plus
3 withdrawn exclusions. 17 rows are verified clean at the snapshot
and form the false positive watch list. Six Maven rows are marked
pending-resolve because transitive versions come from the Spring Boot 2.6.6
BOM; confirm them after the first clone with tools/verify_maven_tree.sh
before treating the Maven counts as final.

GitHub resolves Maven transitives only through the dependency submission
API. The workflow committed at
poc-java-sca/.github/workflows/dependency-submission.yml populates the
dependency graph on push to main and must complete once before Maven
transitive results mean anything.

## Sequence

1. Create the three repositories in the evaluation org.
2. Run ./push.sh with the three remote URLs.
3. Enable dependency graph, alerts, and security updates on each repository.
4. Confirm the dependency submission workflow ran on poc-java-sca.
5. Run tools/verify_maven_tree.sh from a clone of poc-java-sca and update
   any pending-resolve rows that differ.
6. Scan the sca-baseline-v1 tag with the tool under test, export findings,
   and adjudicate against ground-truth/expected_findings.csv.
7. Open a pull request from scenario/sca-02-critical-introduction and record
   the gate behavior against ground-truth/scenario_sca02_expected.csv.

The same tag, register, and scenario branch carry over unchanged to each
tool window. During the consolidation week, rerun every tool against the
tag on the same day and note any advisory database drift by re-running
tools/osv_match.py against a fresh clone of github/advisory-database.
