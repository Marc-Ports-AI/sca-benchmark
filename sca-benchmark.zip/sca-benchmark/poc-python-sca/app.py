"""poc-python-sca service entry point."""

# Tier 1: imported and advisory-relevant API called.
import requests
from flask import Flask, jsonify as flask_jsonify

# Tier 2: imported, advisory-relevant API never called.
import yaml          # only yaml.safe_load is used; unsafe loaders never appear
import fitz          # noqa: F401  (PyMuPDF, license inventory entry)
import sqlparse
from packaging.version import Version

# Tier 3: "future" is pinned in requirements.txt and never imported.

app = Flask(__name__)

CONFIG_YAML = "service: poc-python-sca\nport: 5000\n"


@app.route("/health")
def health():
    cfg = yaml.safe_load(CONFIG_YAML)
    return flask_jsonify(status="ok", service=cfg["service"])


@app.route("/upstream")
def upstream():
    try:
        r = requests.head("https://example.com", timeout=3)
        return flask_jsonify(upstream=r.status_code)
    except requests.RequestException:
        return flask_jsonify(upstream="unreachable")


def normalize_sql(statement: str) -> str:
    return sqlparse.format(statement, reindent=True, keyword_case="upper")


def main():
    cfg = yaml.safe_load(CONFIG_YAML)
    print("parsed config for", cfg["service"])
    print("min supported:", Version("1.0.0"))
    print(normalize_sql("select id, name from accounts where active = 1"))


if __name__ == "__main__":
    main()
