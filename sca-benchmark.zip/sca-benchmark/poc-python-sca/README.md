# poc-python-sca

Flask service with a fully pinned requirements.txt. Part of a dependency
analysis corpus; the pin set is intentional and must not be upgraded.
Direct dependencies are declared in pyproject.toml; requirements.txt is the
resolved set.

Run:

    pip install -r requirements.txt
    python app.py

Branches: main carries the baseline tagged sca-baseline-v1. The branch
scenario/sca-02-critical-introduction adds one dependency and exists for
pull request review checks.
