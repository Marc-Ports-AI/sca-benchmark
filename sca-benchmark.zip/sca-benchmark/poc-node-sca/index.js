'use strict';

// Tier 1: dependency imported and its advisory-relevant API is called.
const _ = require('lodash');
const express = require('express');
const qs = require('qs');
const minimist = require('minimist');
const mkdirp = require('mkdirp');
const fetch = require('node-fetch');

// Tier 2: dependency imported, advisory-relevant API never called.
const ejs = require('ejs'); // eslint-disable-line no-unused-vars
const jsonify = require('jsonify');
const mariadb = require('mariadb'); // eslint-disable-line no-unused-vars

// Tier 3: handlebars is declared in package.json and never imported.

const app = express();

app.get('/health', (req, res) => {
  const merged = _.defaultsDeep({ service: 'poc-node-sca' }, { status: 'ok' });
  res.json(merged);
});

app.get('/echo', (req, res) => {
  const parsed = qs.parse('a=1&b=2');
  res.json(parsed);
});

function main() {
  const args = minimist(['--port', '3000']);
  mkdirp.sync('/tmp/poc-node-sca');
  const payload = jsonify.stringify({ started: true });
  console.log(payload, args.port);

  fetch('https://example.com', { method: 'HEAD' })
    .then((r) => console.log('upstream status', r.status))
    .catch(() => console.log('upstream unreachable'));

  const server = app.listen(args.port, () => {
    console.log('listening on', args.port);
  });
  setTimeout(() => server.close(), 2000);
}

if (require.main === module) {
  main();
}

module.exports = { app };
