# poc-node-sca

Node.js service with a committed package-lock.json. Part of a dependency
analysis corpus; the dependency set is intentional and must not be upgraded.

Run:

    npm ci
    npm start

Branches: main carries the baseline tagged sca-baseline-v1. The branch
scenario/sca-02-critical-introduction adds one dependency and exists for
pull request review checks.
