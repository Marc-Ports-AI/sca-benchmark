"""Query the GitHub Advisory Database for every corpus component and
attribute advisories to specific package@version tuples."""
import json, re, time, urllib.request, urllib.parse, sys

def gh(url):
    req = urllib.request.Request(url, headers={
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
        'User-Agent': 'sca-benchmark-verification'})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.load(r), r.headers.get('X-RateLimit-Remaining')

def vparse(v):
    v = v.strip()
    m = re.match(r'^[0-9]+(\.[0-9]+)*', v)
    nums = [int(x) for x in m.group(0).split('.')] if m else []
    suffix = v[m.end():] if m else v
    return nums, suffix

def vcmp(a, b):
    an, asuf = vparse(a); bn, bsuf = vparse(b)
    for i in range(max(len(an), len(bn))):
        x = an[i] if i < len(an) else 0
        y = bn[i] if i < len(bn) else 0
        if x != y: return -1 if x < y else 1
    # numeric parts equal; a bare version outranks a pre-release suffix
    if asuf and not bsuf: return -1 if any(t in asuf.lower() for t in ('alpha','beta','rc','m','snapshot','-0.')) else 0
    if bsuf and not asuf: return 1 if any(t in bsuf.lower() for t in ('alpha','beta','rc','m','snapshot','-0.')) else 0
    return 0

def in_range(version, range_str):
    if not range_str: return None
    ok = True
    for clause in range_str.split(','):
        clause = clause.strip()
        m = re.match(r'(>=|<=|>|<|=)\s*(.+)$', clause)
        if not m: return None
        op, rv = m.group(1), m.group(2).strip()
        c = vcmp(version, rv)
        if   op == '>=' and c < 0:  ok = False
        elif op == '<=' and c > 0:  ok = False
        elif op == '>'  and c <= 0: ok = False
        elif op == '<'  and c >= 0: ok = False
        elif op == '='  and c != 0: ok = False
    return ok

def batch(ecosystem, tuples, tag):
    affects = ','.join(f"{n}@{v}" for n, v in tuples)
    url = ("https://api.github.com/advisories?ecosystem=" + ecosystem +
           "&per_page=100&affects=" + urllib.parse.quote(affects, safe=',@:'))
    data, rem = gh(url)
    print(f"[{tag}] {len(tuples)} tuples -> {len(data)} advisories | ratelimit left: {rem}", file=sys.stderr)
    if len(data) == 100:
        print(f"[{tag}] WARNING: page full, results may be truncated", file=sys.stderr)
    json.dump(data, open(f"/home/claude/sca-benchmark/ground-truth/ghsa_raw_{tag}.json", "w"), indent=1)
    # attribute
    hits = {f"{n}@{v}": [] for n, v in tuples}
    for adv in data:
        for vul in adv.get('vulnerabilities', []):
            pname = vul['package']['name']
            for n, v in tuples:
                if pname.lower() != n.lower(): continue
                match = in_range(v, vul.get('vulnerable_version_range'))
                if match is not False:
                    hits[f"{n}@{v}"].append({
                        'ghsa': adv['ghsa_id'], 'cve': adv.get('cve_id'),
                        'severity': adv['severity'],
                        'withdrawn': bool(adv.get('withdrawn_at')),
                        'range': vul.get('vulnerable_version_range'),
                        'first_patched': (vul.get('first_patched_version') or ''),
                        'range_parse_uncertain': match is None,
                        'summary': adv['summary'][:80]})
    return hits

# lodash already captured in smoke test; reuse it
lodash_raw = json.load(open('/dev/stdin')) if False else None
all_hits = {}

npm_a = [("express","4.17.1"),("qs","6.7.0"),("qs","6.11.0"),("minimist","0.0.8"),
         ("minimist","1.2.8"),("mkdirp","0.5.1"),("node-fetch","2.7.0"),("node-fetch","2.6.0"),
         ("ejs","3.1.6"),("handlebars","4.7.6"),("dompurify","3.4.11"),("jsonify","0.0.1"),
         ("mariadb","3.5.3"),("body-parser","1.19.0"),("cookie","0.4.0")]
all_hits.update(batch("npm", npm_a, "npm_a")); time.sleep(2)

import json as _j
lock = _j.load(open('/home/claude/sca-benchmark/poc-node-sca/package-lock.json'))
lk = {p.split('node_modules/')[-1]: m.get('version') for p, m in lock['packages'].items() if p}
npm_b_names = ["path-to-regexp","send","serve-static","fresh","mime","debug","ms",
               "http-errors","raw-body","iconv-lite","negotiator","forwarded","ipaddr.js",
               "setprototypeof","statuses","toidentifier","depd","content-disposition"]
npm_b = [(n, lk[n]) for n in npm_b_names if n in lk]
all_hits.update(batch("npm", npm_b, "npm_b")); time.sleep(2)

pip = [("certifi","2024.7.4"),("chardet","3.0.4"),("click","6.7"),("flask","0.12.2"),
       ("future","0.18.2"),("idna","2.7"),("itsdangerous","0.24"),("jinja2","2.10"),
       ("markupsafe","1.1.1"),("packaging","24.1"),("pymupdf","1.24.9"),("pymupdfb","1.24.9"),
       ("pyyaml","5.3.1"),("requests","2.19.1"),("sqlparse","0.5.0"),("urllib3","1.23"),
       ("werkzeug","0.14.1")]
all_hits.update(batch("pip", pip, "pip")); time.sleep(2)

mvn = [("org.apache.logging.log4j:log4j-core","2.14.1"),
       ("org.apache.commons:commons-text","1.9"),
       ("org.springframework.boot:spring-boot-starter-web","2.6.6"),
       ("org.springframework.boot:spring-boot","2.6.6"),
       ("commons-fileupload:commons-fileupload","1.3.2"),
       ("com.google.guava:guava","32.1.3-jre"),
       ("com.mysql:mysql-connector-j","8.2.0"),
       ("com.itextpdf:itextpdf","5.5.13.3"),
       ("org.yaml:snakeyaml","1.29"),
       ("com.fasterxml.jackson.core:jackson-databind","2.13.2.2"),
       ("org.springframework:spring-web","5.3.18"),
       ("org.apache.tomcat.embed:tomcat-embed-core","9.0.60")]
all_hits.update(batch("maven", mvn, "maven"))

json.dump(all_hits, open('/home/claude/sca-benchmark/ground-truth/ghsa_attributed.json','w'), indent=1)
for k in sorted(all_hits):
    advs = [h for h in all_hits[k] if not h['withdrawn']]
    wd = [h for h in all_hits[k] if h['withdrawn']]
    sev = {}
    for h in advs: sev[h['severity']] = sev.get(h['severity'], 0) + 1
    flag = " +%dwithdrawn" % len(wd) if wd else ""
    unc = sum(1 for h in advs if h['range_parse_uncertain'])
    uflag = f" ({unc} uncertain)" if unc else ""
    print(f"{k:55s} {len(advs):2d} advisories {dict(sorted(sev.items()))}{flag}{uflag}")
