"""Offline advisory attribution against a pinned snapshot of the
github/advisory-database reviewed set (OSV format)."""
import json, os, re, sys
from pathlib import Path

DB = Path('/home/claude/advisory-database/advisories/github-reviewed')
OUT = Path('/home/claude/sca-benchmark/ground-truth')

def norm_pypi(n): return re.sub(r'[-_.]+', '-', n).lower()

def vparse(v):
    v = str(v).strip()
    m = re.match(r'^[0-9]+(\.[0-9]+)*', v)
    nums = [int(x) for x in m.group(0).split('.')] if m else []
    suffix = v[m.end():] if m else v
    return nums, suffix.lower()

PRE = ('alpha','beta','rc','milestone','snapshot','m1','m2','m3','cr','dev','a','b')
def vcmp(a, b):
    an, asuf = vparse(a); bn, bsuf = vparse(b)
    for i in range(max(len(an), len(bn))):
        x = an[i] if i < len(an) else 0
        y = bn[i] if i < len(bn) else 0
        if x != y: return -1 if x < y else 1
    def is_pre(s): return bool(s) and any(s.strip('.-_').startswith(t) for t in PRE)
    if is_pre(asuf) and not is_pre(bsuf): return -1
    if is_pre(bsuf) and not is_pre(asuf): return 1
    return 0

# ---- load corpus tuples ----
targets = []  # (ecosystem, name, version, repo)
lock = json.load(open('/home/claude/sca-benchmark/poc-node-sca/package-lock.json'))
seen = set()
for p, m in lock['packages'].items():
    if not p: continue
    name = p.split('node_modules/')[-1]
    key = (name, m.get('version'))
    if key in seen: continue
    seen.add(key)
    targets.append(('npm', name, m['version'], 'poc-node-sca'))
for line in open('/home/claude/sca-benchmark/poc-python-sca/requirements.txt'):
    line = line.split('#')[0].strip()
    if not line: continue
    n, v = line.split('==')
    targets.append(('PyPI', n.strip(), v.strip(), 'poc-python-sca'))
mvn = [("org.apache.logging.log4j:log4j-core","2.14.1"),("org.apache.commons:commons-text","1.9"),
       ("org.springframework.boot:spring-boot-starter-web","2.6.6"),("org.springframework.boot:spring-boot","2.6.6"),
       ("org.springframework.boot:spring-boot-autoconfigure","2.6.6"),
       ("commons-fileupload:commons-fileupload","1.3.2"),("com.google.guava:guava","32.1.3-jre"),
       ("com.mysql:mysql-connector-j","8.2.0"),("com.itextpdf:itextpdf","5.5.13.3"),
       ("org.yaml:snakeyaml","1.29"),("com.fasterxml.jackson.core:jackson-databind","2.13.2.2"),
       ("org.springframework:spring-web","5.3.18"),("org.apache.tomcat.embed:tomcat-embed-core","9.0.60")]
for n, v in mvn:
    targets.append(('Maven', n, v, 'poc-java-sca'))

wanted = {}
for eco, n, v, repo in targets:
    k = (eco, norm_pypi(n) if eco == 'PyPI' else n.lower())
    wanted.setdefault(k, []).append((n, v, repo))
print(f"corpus tuples: {len(targets)}", file=sys.stderr)

# ---- walk the database ----
hits = {}
files = list(DB.rglob('GHSA-*.json'))
print(f"advisory files: {len(files)}", file=sys.stderr)
matched_advisories = 0
for f in files:
    try:
        adv = json.load(open(f))
    except Exception:
        continue
    relevant = False
    for aff in adv.get('affected', []):
        pkg = aff.get('package', {})
        eco = pkg.get('ecosystem'); name = pkg.get('name','')
        k = (eco, norm_pypi(name) if eco == 'PyPI' else name.lower())
        if k not in wanted: continue
        relevant = True
        for n, v, repo in wanted[k]:
            affected = None
            if aff.get('versions'):
                affected = v in aff['versions']
            if affected is not True:
                for rng in aff.get('ranges', []):
                    if rng.get('type') not in ('ECOSYSTEM','SEMVER'): continue
                    intro, fixed, last = '0', None, None
                    for ev in rng.get('events', []):
                        if 'introduced' in ev: intro = ev['introduced']
                        if 'fixed' in ev: fixed = ev['fixed']
                        if 'last_affected' in ev: last = ev['last_affected']
                    ok = vcmp(v, intro) >= 0
                    if fixed is not None: ok = ok and vcmp(v, fixed) < 0
                    if last  is not None: ok = ok and vcmp(v, last) <= 0
                    if ok: affected = True
            if affected:
                sev = adv.get('database_specific', {}).get('severity', '')
                cves = [a for a in adv.get('aliases', []) if a.startswith('CVE-')]
                fixed_versions = sorted({ev.get('fixed') for a2 in adv.get('affected', [])
                                         if a2.get('package',{}).get('name','').lower() == name.lower()
                                         for r2 in a2.get('ranges', []) for ev in r2.get('events', []) if ev.get('fixed')})
                hits.setdefault(f"{eco}|{n}@{v}", []).append({
                    'ghsa': adv['id'], 'cve': cves[0] if cves else None,
                    'severity': sev, 'withdrawn': bool(adv.get('withdrawn')),
                    'first_patched': fixed_versions[0] if fixed_versions else '',
                    'published': adv.get('published','')[:10],
                    'summary': adv.get('summary','')[:90]})
    if relevant: matched_advisories += 1
print(f"advisories touching corpus packages: {matched_advisories}", file=sys.stderr)

json.dump(hits, open(OUT / 'advisory_attribution.json', 'w'), indent=1)
meta = {'source': 'github/advisory-database (github-reviewed)',
        'snapshot_sha': '524f896ffaae2a2b42c61096d6c94d8e3984edcd',
        'snapshot_date': '2026-07-06T22:55:38+00:00'}
json.dump(meta, open(OUT / 'advisory_db_snapshot.json', 'w'), indent=1)

# summary
flagged = 0
for eco, n, v, repo in targets:
    key = f"{eco}|{n}@{v}"
    advs = [h for h in hits.get(key, []) if not h['withdrawn']]
    wd = len(hits.get(key, [])) - len(advs)
    if advs or wd:
        flagged += 1
        sevs = {}
        for h in advs: sevs[h['severity']] = sevs.get(h['severity'],0)+1
        wtxt = f" +{wd} withdrawn" if wd else ""
        print(f"{eco:5s} {n+'@'+v:52s} {len(advs):2d} {dict(sorted(sevs.items()))}{wtxt}")
print(f"\ntuples with at least one advisory: {flagged} / {len(targets)}")
