#!/usr/bin/env bash
# Confirms the resolved versions of the Maven rows marked pending-resolve in
# the ground truth register. Run from inside poc-java-sca after cloning.
set -euo pipefail

TREE="$(mktemp)"
mvn -q dependency:tree -DoutputFile="$TREE" -DappendOutput=false > /dev/null

declare -A EXPECT=(
  ["org.yaml:snakeyaml"]="1.29"
  ["com.fasterxml.jackson.core:jackson-databind"]="2.13.2.2"
  ["org.springframework:spring-web"]="5.3.18"
  ["org.springframework.boot:spring-boot"]="2.6.6"
  ["org.springframework.boot:spring-boot-autoconfigure"]="2.6.6"
  ["org.apache.tomcat.embed:tomcat-embed-core"]="9.0.60"
)

rc=0
for ga in "${!EXPECT[@]}"; do
  want="${EXPECT[$ga]}"
  found="$(grep -o "$ga:jar:[^: ]*" "$TREE" | head -1 | awk -F: '{print $4}')"
  if [ "$found" = "$want" ]; then
    echo "PASS  $ga  $found"
  else
    echo "FAIL  $ga  expected $want, resolved ${found:-none}"
    rc=1
  fi
done
rm -f "$TREE"
exit $rc
