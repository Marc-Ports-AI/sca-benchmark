"""Build the expected-findings register from probe metadata plus the
attributed advisory snapshot."""
import csv, json
from pathlib import Path

GT = Path('/home/claude/sca-benchmark/ground-truth')
attr = json.load(open(GT / 'advisory_attribution.json'))
snap = json.load(open(GT / 'advisory_db_snapshot.json'))

def adv(eco, name, ver):
    return attr.get(f"{eco}|{name}@{ver}", [])

# probe metadata: (id, repo, eco, name, version, relation, chain, reachability, intended_class, tags, notes)
P = []
P += [
 ("N-01","poc-node-sca","npm","lodash","4.17.11","direct","", "called",
  "tp-direct", ["stale-lock"],
  "package.json range ^4.17.11 admits patched releases; package-lock.json pins 4.17.11. Lockfile-aware tools must report; manifest-only resolution may miss."),
 ("N-02","poc-node-sca","npm","minimist","0.0.8","transitive","mkdirp > minimist","n/a",
  "tp-transitive", ["dedup-multiversion"],
  "Depth 2. Root also declares minimist 1.2.8; correct output separates the two versions."),
 ("N-03","poc-node-sca","npm","qs","6.7.0","transitive","express > qs; express > body-parser > qs","n/a",
  "tp-transitive", ["dedup-multipath","dedup-multiversion"],
  "Installed at two paths. Canonical counting: one tuple regardless of path count. Root also declares qs 6.11.0."),
 ("N-04","poc-node-sca","npm","express","4.17.1","direct","","called",
  "tp-direct", ["withdrawn-present"],
  "One withdrawn advisory also matches this version; findings on withdrawn advisories are excluded from scoring."),
 ("N-05","poc-node-sca","npm","body-parser","1.19.0","transitive","express > body-parser","n/a","tp-transitive", [], ""),
 ("N-06","poc-node-sca","npm","cookie","0.4.0","transitive","express > cookie","n/a","tp-transitive", [], ""),
 ("N-07","poc-node-sca","npm","path-to-regexp","0.1.7","transitive","express > path-to-regexp","n/a","tp-transitive", [], ""),
 ("N-08","poc-node-sca","npm","send","0.17.1","transitive","express > send","n/a","tp-transitive", [], ""),
 ("N-09","poc-node-sca","npm","serve-static","1.14.1","transitive","express > serve-static","n/a","tp-transitive", [], ""),
 ("N-10","poc-node-sca","npm","ejs","3.1.6","direct","","imported-only",
  "tp-direct", ["reachability-tier"],
  "Module is required; render APIs are never invoked. Reachability-capable tools should mark low exploitability."),
 ("N-11","poc-node-sca","npm","handlebars","4.7.6","direct","","declared-only",
  "tp-direct", ["reachability-tier"],
  "Declared in package.json; no source file imports it."),
 ("N-12","poc-node-sca","npm","node-fetch","2.7.0","direct","","called",
  "manifest-floor", [],
  "Manifest range ^2.6.0 has a floor with known advisories; lockfile resolves 2.7.0 which is clean. Correct result: no finding. A finding here indicates manifest-floor evaluation."),
 ("N-13","poc-node-sca","npm","qs","6.11.0","direct","","called",
  "tp-direct", ["reclassified"],
  "Selected as a post-fix version of CVE-2022-24999; advisories published after selection now match 6.11.0. Register follows the snapshot."),
 ("N-14","poc-node-sca","npm","minimist","1.2.8","direct","","called",
  "expected-clean", ["dedup-multiversion"], "Verified zero advisories at snapshot."),
 ("N-15","poc-node-sca","npm","mkdirp","0.5.1","direct","","called",
  "expected-clean", ["carrier"], "Carrier for N-02. Verified zero advisories at snapshot."),
 ("N-16","poc-node-sca","npm","dompurify","3.4.11","direct","","imported-only",
  "expected-clean", ["license-dual"], "License: (MPL-2.0 OR Apache-2.0)."),
 ("N-17","poc-node-sca","npm","jsonify","0.0.1","direct","","called",
  "expected-clean", ["license-unknown"], "Declared license: Public Domain. Exercises unrecognized-license handling."),
 ("N-18","poc-node-sca","npm","mariadb","3.5.3","direct","","imported-only",
  "expected-clean", ["license-lgpl"], "License: LGPL-2.1-or-later."),
]
P += [
 ("P-01","poc-python-sca","PyPI","requests","2.19.1","direct","","called","tp-direct", [], ""),
 ("P-02","poc-python-sca","PyPI","flask","0.12.2","direct","","called","tp-direct", [], ""),
 ("P-03","poc-python-sca","PyPI","jinja2","2.10","transitive","flask > jinja2","n/a","tp-transitive", [], ""),
 ("P-04","poc-python-sca","PyPI","werkzeug","0.14.1","transitive","flask > werkzeug","n/a","tp-transitive", [], ""),
 ("P-05","poc-python-sca","PyPI","urllib3","1.23","transitive","requests > urllib3","n/a",
  "tp-transitive", ["volume"], "Highest advisory count in the Python set; exercises grouping and pagination in vendor UIs."),
 ("P-06","poc-python-sca","PyPI","idna","2.7","transitive","requests > idna","n/a","tp-transitive", [], ""),
 ("P-07","poc-python-sca","PyPI","pyyaml","5.3.1","direct","","imported-only",
  "tp-direct", ["reachability-tier"],
  "Only yaml.safe_load appears in source. The advisory concerns unsafe loader paths that are never called."),
 ("P-08","poc-python-sca","PyPI","future","0.18.2","direct","","declared-only",
  "tp-direct", ["reachability-tier","withdrawn-present"], "Pinned in both manifests; never imported."),
 ("P-09","poc-python-sca","PyPI","sqlparse","0.5.0","direct","","called",
  "tp-direct", ["reclassified"],
  "Selected as a post-fix version of CVE-2024-4340; a later advisory now matches 0.5.0. Register follows the snapshot."),
 ("P-10","poc-python-sca","PyPI","certifi","2024.7.4","transitive","requests > certifi","n/a",
  "expected-clean", [], "Post-fix version of CVE-2024-39689. Verified zero advisories at snapshot."),
 ("P-11","poc-python-sca","PyPI","chardet","3.0.4","transitive","requests > chardet","n/a",
  "expected-clean", ["license-lgpl"], "License: LGPL. Copyleft entry arriving transitively."),
 ("P-12","poc-python-sca","PyPI","pymupdf","1.24.9","direct","","imported-only",
  "expected-clean", ["license-agpl"], "License: AGPL-3.0. Primary copyleft policy entry for Python."),
 ("P-13","poc-python-sca","PyPI","pymupdfb","1.24.9","transitive","pymupdf > pymupdfb","n/a",
  "expected-clean", ["license-agpl"], ""),
 ("P-14","poc-python-sca","PyPI","packaging","24.1","direct","","called",
  "expected-clean", ["license-dual"], "License: (Apache-2.0 OR BSD-2-Clause)."),
 ("P-15","poc-python-sca","PyPI","markupsafe","1.1.1","transitive","flask > jinja2 > markupsafe","n/a",
  "expected-clean", [], "Depth 3 clean entry."),
 ("P-16","poc-python-sca","PyPI","click","6.7","transitive","flask > click","n/a","expected-clean", [], ""),
 ("P-17","poc-python-sca","PyPI","itsdangerous","0.24","transitive","flask > itsdangerous","n/a",
  "expected-clean", ["license-unknown"], "PyPI metadata declares license UNKNOWN."),
]
P += [
 ("M-01","poc-java-sca","Maven","org.apache.logging.log4j:log4j-core","2.14.1","direct","","called",
  "tp-direct", ["remediation-quality"],
  "Advisory chain spans four fix boundaries; remediation suggestions are scored on reaching the version that clears all live advisories, not only CVE-2021-44228."),
 ("M-02","poc-java-sca","Maven","org.apache.commons:commons-text","1.9","direct","","called","tp-direct", [], ""),
 ("M-03","poc-java-sca","Maven","org.yaml:snakeyaml","1.29","transitive","spring-boot-starter-web > spring-boot-starter > snakeyaml","n/a",
  "tp-transitive", ["pending-resolve"],
  "Expected from the Spring Boot 2.6.6 BOM. Confirm version with: mvn dependency:tree -Dincludes=org.yaml:snakeyaml"),
 ("M-04","poc-java-sca","Maven","com.fasterxml.jackson.core:jackson-databind","2.13.2.2","transitive",
  "spring-boot-starter-web > spring-boot-starter-json > jackson-databind","called",
  "tp-transitive", ["pending-resolve","reachability-tier"],
  "Depth 3. Source imports and calls ObjectMapper without enabling default typing. Confirm version with: mvn dependency:tree -Dincludes=com.fasterxml.jackson.core:jackson-databind"),
 ("M-05","poc-java-sca","Maven","org.springframework:spring-web","5.3.18","transitive",
  "spring-boot-starter-web > spring-web","n/a",
  "tp-transitive", ["pending-resolve","disputed"],
  "Matching set includes CVE-2016-1000027, which Spring disputes as usage-dependent. Record each tool's disposition; suppression with rationale and a flag are both acceptable, silence is not."),
 ("M-06","poc-java-sca","Maven","org.springframework.boot:spring-boot","2.6.6","transitive",
  "spring-boot-starter-web > spring-boot","n/a","tp-transitive", ["pending-resolve"], ""),
 ("M-07","poc-java-sca","Maven","org.springframework.boot:spring-boot-autoconfigure","2.6.6","transitive",
  "spring-boot-starter-web > spring-boot-autoconfigure","n/a","tp-transitive", ["pending-resolve"], ""),
 ("M-08","poc-java-sca","Maven","org.apache.tomcat.embed:tomcat-embed-core","9.0.60","transitive",
  "spring-boot-starter-web > spring-boot-starter-tomcat > tomcat-embed-core","n/a",
  "organic-volume", ["pending-resolve","volume"],
  "Thirty-seven live advisories at snapshot. Scored on canonical-tuple counting and grouping behavior, not enumerated per advisory."),
 ("M-09","poc-java-sca","Maven","commons-fileupload:commons-fileupload","1.3.2","direct","","declared-only",
  "tp-direct", ["reachability-tier"], "Declared in pom.xml; no source file imports it."),
 ("M-10","poc-java-sca","Maven","com.google.guava:guava","32.1.3-jre","direct","","declared-only",
  "expected-clean", [], "Post-fix version of CVE-2023-2976. Verified zero advisories at snapshot."),
 ("M-11","poc-java-sca","Maven","com.mysql:mysql-connector-j","8.2.0","direct","","declared-only",
  "expected-clean", ["license-gpl-exception"],
  "Post-fix version of CVE-2023-22102. License: GPL-2.0 with FOSS exception; primary GPL policy entry for Java."),
 ("M-12","poc-java-sca","Maven","com.itextpdf:itextpdf","5.5.13.3","direct","","declared-only",
  "expected-clean", ["license-agpl"], "License: AGPL-3.0. Verified zero advisories at snapshot."),
 ("M-13","poc-java-sca","Maven","org.springframework.boot:spring-boot-starter-web","2.6.6","direct","","declared-only",
  "expected-clean", ["carrier"], "Carrier for the Maven transitive set. Zero advisories attach to the starter artifact itself."),
]

def clean_all_fix(advs):
    live = [a for a in advs if not a['withdrawn'] and a.get('first_patched')]
    if not live: return ''
    best = ''
    for a in live:
        if not best or _gt(a['first_patched'], best): best = a['first_patched']
    return best

import re
def _v(x):
    m = re.match(r'^[0-9]+(\.[0-9]+)*', x)
    return [int(t) for t in m.group(0).split('.')] if m else [0]
def _gt(a, b):
    va, vb = _v(a), _v(b)
    for i in range(max(len(va), len(vb))):
        x = va[i] if i < len(va) else 0
        y = vb[i] if i < len(vb) else 0
        if x != y: return x > y
    return False

register, findings, problems = [], [], []
for pid, repo, eco, name, ver, rel, chain, reach, cls, tags, notes in P:
    advs = adv(eco, name, ver)
    live = [a for a in advs if not a['withdrawn']]
    wd   = [a for a in advs if a['withdrawn']]
    if cls.startswith('tp') and not live:
        problems.append(f"{pid}: classed {cls} but zero live advisories")
    if cls in ('expected-clean','manifest-floor') and live:
        problems.append(f"{pid}: classed {cls} but {len(live)} live advisories")
    register.append({'probe_id': pid, 'repo': repo, 'ecosystem': eco, 'package': name,
        'version': ver, 'relation': rel, 'chain': chain, 'reachability': reach,
        'probe_class': cls, 'tags': ';'.join(tags),
        'live_advisories': len(live), 'withdrawn_advisories': len(wd),
        'max_severity': max((a['severity'] for a in live), key=lambda s: ['LOW','MODERATE','HIGH','CRITICAL'].index(s)) if live else '',
        'fix_clears_all': clean_all_fix(advs), 'notes': notes})
    for a in live:
        findings.append({'probe_id': pid, 'repo': repo, 'ecosystem': eco, 'package': name,
            'version': ver, 'relation': rel, 'ghsa_id': a['ghsa'], 'cve_id': a['cve'] or '',
            'severity': a['severity'], 'first_patched': a['first_patched'],
            'published': a['published'], 'summary': a['summary']})
    for a in wd:
        findings.append({'probe_id': pid, 'repo': repo, 'ecosystem': eco, 'package': name,
            'version': ver, 'relation': rel, 'ghsa_id': a['ghsa'], 'cve_id': a['cve'] or '',
            'severity': 'WITHDRAWN', 'first_patched': a['first_patched'],
            'published': a['published'], 'summary': 'WITHDRAWN: ' + a['summary']})

with open(GT / 'component_register.csv', 'w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=list(register[0].keys()))
    w.writeheader(); w.writerows(register)
with open(GT / 'expected_findings.csv', 'w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=list(findings[0].keys()))
    w.writeheader(); w.writerows(findings)
json.dump({'snapshot': snap, 'register': register, 'expected_findings': findings},
          open(GT / 'expected_findings.json', 'w'), indent=1)

live_ct = sum(1 for x in findings if x['severity'] != 'WITHDRAWN')
wd_ct = len(findings) - live_ct
by_class = {}
for r in register: by_class[r['probe_class']] = by_class.get(r['probe_class'], 0) + 1
print(f"register rows: {len(register)} | expected findings (live): {live_ct} | withdrawn exclusions: {wd_ct}")
print("by class:", json.dumps(by_class, indent=1))
if problems:
    print("CLASSIFICATION PROBLEMS:"); [print(" -", p) for p in problems]
else:
    print("classification consistency: all rows agree with the snapshot")
