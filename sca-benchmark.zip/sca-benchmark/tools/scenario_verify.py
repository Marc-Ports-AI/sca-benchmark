"""Attribute advisories to the SCA-02 scenario packages against the same
pinned database snapshot used for the baseline register."""
import csv, json, re, subprocess, sys
from pathlib import Path

DB = Path('/home/claude/advisory-database/advisories/github-reviewed')
GT = Path('/home/claude/sca-benchmark/ground-truth')

def norm_pypi(n): return re.sub(r'[-_.]+', '-', n).lower()

def vparse(v):
    v = str(v).strip()
    m = re.match(r'^[0-9]+(\.[0-9]+)*', v)
    nums = [int(x) for x in m.group(0).split('.')] if m else []
    return nums, (v[m.end():] if m else v).lower()

PRE = ('alpha','beta','rc','milestone','snapshot','m1','m2','m3','cr','dev','a','b')
def vcmp(a, b):
    an, asuf = vparse(a); bn, bsuf = vparse(b)
    for i in range(max(len(an), len(bn))):
        x = an[i] if i < len(an) else 0
        y = bn[i] if i < len(bn) else 0
        if x != y: return -1 if x < y else 1
    def is_pre(s): return bool(s) and any(s.strip('.-_').startswith(t) for t in PRE)
    if is_pre(asuf) and not is_pre(bsuf): return -1
    if is_pre(bsuf) and not is_pre(asuf): return 1
    return 0

targets = [('npm','vm2','3.9.19'),
           ('PyPI','pillow','8.1.0'),
           ('Maven','commons-collections:commons-collections','3.2.1')]

# grep prefilter keeps the walk cheap
names = ['"vm2"', '"Pillow"', '"pillow"', 'commons-collections']
files = set()
for n in names:
    out = subprocess.run(['grep','-rl','--include=*.json', n, str(DB)],
                         capture_output=True, text=True)
    files.update(out.stdout.split())
print(f"prefiltered files: {len(files)}", file=sys.stderr)

rows = []
for fp in sorted(files):
    try: adv = json.load(open(fp))
    except Exception: continue
    for aff in adv.get('affected', []):
        pkg = aff.get('package', {})
        eco, name = pkg.get('ecosystem'), pkg.get('name','')
        for teco, tn, tv in targets:
            if eco != teco: continue
            if eco == 'PyPI':
                if norm_pypi(name) != norm_pypi(tn): continue
            elif name.lower() != tn.lower(): continue
            affected = None
            if aff.get('versions'): affected = tv in aff['versions']
            if affected is not True:
                for rng in aff.get('ranges', []):
                    if rng.get('type') not in ('ECOSYSTEM','SEMVER'): continue
                    intro, fixed, last = '0', None, None
                    for ev in rng.get('events', []):
                        if 'introduced' in ev: intro = ev['introduced']
                        if 'fixed' in ev: fixed = ev['fixed']
                        if 'last_affected' in ev: last = ev['last_affected']
                    ok = vcmp(tv, intro) >= 0
                    if fixed is not None: ok = ok and vcmp(tv, fixed) < 0
                    if last  is not None: ok = ok and vcmp(tv, last) <= 0
                    if ok: affected = True
            if affected:
                cves = [a for a in adv.get('aliases', []) if a.startswith('CVE-')]
                fx = sorted({ev.get('fixed') for a2 in adv.get('affected', [])
                             if a2.get('package',{}).get('name','').lower() == name.lower()
                             for r2 in a2.get('ranges', []) for ev in r2.get('events', []) if ev.get('fixed')})
                rows.append({'scenario':'SCA-02','ecosystem':teco,'package':tn,'version':tv,
                    'ghsa_id':adv['id'],'cve_id':cves[0] if cves else '',
                    'severity':adv.get('database_specific',{}).get('severity',''),
                    'withdrawn':bool(adv.get('withdrawn')),
                    'first_patched':fx[0] if fx else '',
                    'summary':adv.get('summary','')[:90]})

with open(GT/'scenario_sca02_expected.csv','w',newline='') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    w.writeheader(); w.writerows(rows)
for r in rows:
    tag = 'WITHDRAWN ' if r['withdrawn'] else ''
    fix = r['first_patched'] or 'none available'
    print(f"{r['ecosystem']:5s} {r['package']+'@'+r['version']:45s} {r['ghsa_id']} {r['cve_id']:16s} {tag}{r['severity']:8s} fix: {fix}")
